import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learner-dashboard',
  templateUrl: './learner-dashboard.component.html',
  styleUrls: ['./learner-dashboard.component.css']
})
export class LearnerDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
