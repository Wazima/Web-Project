import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course-enrollment',
  templateUrl: './course-enrollment.component.html',
  styleUrls: ['./course-enrollment.component.css']
})
export class CourseEnrollmentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
